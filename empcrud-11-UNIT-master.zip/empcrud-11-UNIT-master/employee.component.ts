import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms';
import {EmployeeService} from '../sharedEmployees/employee.service';
import {Employee} from '../sharedEmployees/employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(public employeeservice : EmployeeService) { }

  ngOnInit() {
    this.FormReset();
  }
  FormReset(form? : NgForm){
    if(form != null)form.reset();
    this.employeeservice.SelectedEmployee ={
      EmployeeID : null,
      Firstname : '',
      Lastname : '',
      mobile : '',
      Position : ''
    }
  }

  Onsubmit(form: NgForm) {
    if (form.value.EmployeeID == null) {
      this.employeeservice.PostEmployee(form.value)
        .subscribe(data => {
          this.FormReset(form);
          this.employeeservice.GetEmployee();
          //this.toastr.success('New Record Added Succcessfully', 'Employee Register');
        })
    }
    else {
      this.employeeservice.putEmployee(form.value.EmployeeID, form.value)
      .subscribe(data => {
        this.FormReset(form);
        this.employeeservice.GetEmployee();
       // this.toastr.info('Record Updated Successfully!', 'Employee Register');
      });
    }
  }

}
