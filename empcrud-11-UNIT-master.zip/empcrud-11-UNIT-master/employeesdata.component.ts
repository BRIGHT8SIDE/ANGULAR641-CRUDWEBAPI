import { Component, OnInit } from '@angular/core';
import {EmployeeService} from './sharedEmployees/employee.service';

@Component({
  selector: 'app-employeesdata',
  templateUrl: './employeesdata.component.html',
  styleUrls: ['./employeesdata.component.css']
})
export class EmployeesdataComponent implements OnInit {

  constructor(public employeeservice : EmployeeService) { }

  ngOnInit() {
  }

}
