import { Component, OnInit } from '@angular/core';
import {NgForm} from '@angular/forms'
import {EmployeeService} from '../sharedEmployees/employee.service';
import {Employee} from '../sharedEmployees/employee';


@Component({
  selector: 'app-employee-lists',
  templateUrl: './employee-lists.component.html',
  styleUrls: ['./employee-lists.component.css']
})
export class EmployeeListsComponent implements OnInit {

  constructor(public employeeservice : EmployeeService) { }

  ngOnInit() {
    this.employeeservice.GetEmployee();
  }
  showForEdit(emp : Employee){
    this.employeeservice.SelectedEmployee = Object.assign({}, emp);;
  }

  onDelete(id : number){
    if(confirm('Are U sure to delete this record ?') == true){
      this.employeeservice.deleteEmployee(id).subscribe(x =>{
        this.employeeservice.GetEmployee();
      })
    }
  }
}
