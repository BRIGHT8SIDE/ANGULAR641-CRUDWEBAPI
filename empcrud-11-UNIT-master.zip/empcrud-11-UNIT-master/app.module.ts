import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeesdataComponent } from './employeesdata/employeesdata.component';
import { EmployeeComponent } from './employeesdata/employee/employee.component';
import { EmployeeListsComponent } from './employeesdata/employee-lists/employee-lists.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeesdataComponent,
    EmployeeComponent,
    EmployeeListsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
