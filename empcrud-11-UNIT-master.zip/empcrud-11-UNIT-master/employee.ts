export class Employee {

     EmployeeID : number;
     Firstname : string ;
     Lastname : string;
     mobile : string ;
     Position : string;
}
